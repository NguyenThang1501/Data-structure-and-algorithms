package hw6_21002174.exercise1;

public interface Entry <K,E>{
    K getKey();
    E getValue();
}
